CUDA_VISIBLE_DEVICES=4 python train_end2end.py --exp_code 'FT_Camelyon16_res50' --k_start 0 --k_end 5 --bag_size 512 --data_root_dir '/kaggle/working/WSI-finetuning/data_feat/Camel16_ostu_top512_vib'
