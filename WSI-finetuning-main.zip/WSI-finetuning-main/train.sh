CUDA_VISIBLE_DEVICES=0 python train_stage1.py --exp_code 'clam_cam16_res50_ostu_init'
